function Contact() {
    return (
        <div className="p-8">
            <h2 className="text-3xl font-bold mb-4">Contact us</h2>
            <p>Email: flirtingsingles@gmail.com</p>
            <p>Email: get.connected@flirtingsingle.com</p>
            <p>Phone: +1 (501) 803-6579</p>
            <p>Phone: +1 (501) 414-5627</p>
        </div>
    );
}

export default Contact;