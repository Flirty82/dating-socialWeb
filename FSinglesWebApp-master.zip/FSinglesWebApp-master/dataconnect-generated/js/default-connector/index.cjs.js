
const connectorConfig = {
  connector: 'default',
  service: 'fsingleswebapp',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
