This file explains how Visual Studio created the project.

The following tools were used to generate this project:
- Express generator

The following steps were used to generate this project:
- Create express project with express-generator: `npx express-generator --view=pug C:\Users\flirt\OneDrive\Desktop\Fsingles-project\FSinglesWebApp\FSinglesWebApp`.
- Create project file (`FSinglesWebApp.esproj`).
- Create `launch.json` to enable debugging.
- Add project to solution.
- Write this file.
