const predefinedRooms = [
    { name: 'Ages 18-25', description: 'Chat for ages 18 to 25' },
    { name: 'Ages 26-35' description: 'Chat for ages 26 to 36' },
    { name: 'Ages 36-45' description: 'Chat for ages 36 to 45' },
    { name: 'Ages 46+' description: 'Chat for ages 46 and older' },
    { name: 'Country Vibes' description: 'Counrty lifestyle and love' },
    {
        name: 'Outdoor Lovers' description: 'Chat for anyone who loves and enjoys being outside'
    },
    {
        name: 'Casual Dating' description: 'Chill no pressure dating'
    },
    name: 'Hookups' description: 'For one time flings (one night stands)'},
name: 'B.f.Fs' description: 'Find your new bestfriend!'},
name: 'Dating Experiences' description: 'Share dating stories, experiences, and more!'
];